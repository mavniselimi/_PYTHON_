
sayi = int(input("Sayi giriniz:"))
 
faktoriyel = 1
 
while(sayi>1):
    faktoriyel *= sayi
    sayi -= 1
 
print("Sonuc:",faktoriyel)
