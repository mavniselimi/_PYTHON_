deger=1
x=int(input("Bir sayı giriniz:"))
y=int(input("Bir sayı giriniz:"))
for i in range(1,y+1):
    deger*=x
print(deger)
