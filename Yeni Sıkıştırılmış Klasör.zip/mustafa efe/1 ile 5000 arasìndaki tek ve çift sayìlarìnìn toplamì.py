sayac=0
for x in range(1,5000):
    if x%2==0:
        sayac+=x
print(sayac)
sayac2=0
for y in range(1,5000):
    if x%2==1:
        sayac2+=y
print(sayac2)
      
    
