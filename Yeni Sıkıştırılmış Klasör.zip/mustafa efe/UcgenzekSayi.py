a=1
k=0
f=int(input("Bir sayi gir:"))
for i in range(1,f+1):
    k+=i
print(f,".Ucgensel sayi",k)
