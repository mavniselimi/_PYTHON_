for b in range(1,11):
    for a in range(1,11):
        print(a,"x",b,"=",a*b)
