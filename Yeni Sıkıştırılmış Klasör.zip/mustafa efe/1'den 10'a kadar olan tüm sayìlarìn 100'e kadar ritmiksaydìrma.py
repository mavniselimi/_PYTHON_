for a in range(2,10):
    for b in range(a,101,a):
       print(b,end=" ")
    print()
