a=[]
for i in range(1,1001):
    a.append(pow(i,i))
print(a[10])
