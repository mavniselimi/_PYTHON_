import random
random.randint(1,100)
