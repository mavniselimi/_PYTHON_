a=int(input("Bir Sayi Gir"))
p=0
for i in range(1,a+1):
    p+=pow(a,a)
print(p)
